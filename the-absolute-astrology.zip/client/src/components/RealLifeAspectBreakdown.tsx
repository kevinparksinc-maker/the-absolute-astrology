import React, { useState, useMemo } from "react";
import type { ChartResult, TransitContact, MinorTransitContact } from "../../../server/astronomy";
import { getHumanDialogue, type HumanAspectDialogue } from "@/lib/humanDialogueEngine";
import { ENERGY_ASPECT_FLOW } from "@/lib/energyScoring";
import {
  Sparkles,
  Briefcase,
  Heart,
  Zap,
  AlertCircle,
  CheckCircle2,
  Filter,
  MessageSquare,
  HelpCircle,
  Flame,
  Shield,
  Compass,
} from "lucide-react";

const MAJOR_ASPECTS = new Set(["conjunction", "trine", "sextile", "square", "opposition"]);

const ASPECT_GLYPHS: Record<string, string> = {
  conjunction: "☌",
  semisextile: "⚺",
  semisquare: "∠",
  quincunx: "⚻",
  sextile: "⚹",
  square: "□",
  trine: "△",
  opposition: "☍",
};

const PLANET_GLYPHS: Record<string, string> = {
  Sun: "☉", Moon: "☽", Mercury: "☿", Venus: "♀", Mars: "♂",
  Jupiter: "♃", Saturn: "♄", Uranus: "♅", Neptune: "♆", Pluto: "♇",
  "North Node": "☊", "South Node": "☋", Ascendant: "AC",
};

interface RealLifeAspectBreakdownProps {
  chart: ChartResult;
  contacts: any[];
  onAskQuestion?: (question: string) => void;
}

export function RealLifeAspectBreakdown({ chart, contacts, onAskQuestion }: RealLifeAspectBreakdownProps) {
  const [lifeArea, setLifeArea] = useState<"all" | "work" | "love" | "mind">("all");
  const [impactFilter, setImpactFilter] = useState<"all" | "major" | "minor" | "flow" | "friction">("all");
  const [searchQuery, setSearchQuery] = useState("");

  // Process contacts into HumanDialogue items
  const aspectItems = useMemo(() => {
    return (contacts || []).map((c: any) => {
      const isMajor = c.majorFactor === 1 || MAJOR_ASPECTS.has(c.aspect);
      const isFlow = c.flow === 1 || (ENERGY_ASPECT_FLOW as Record<string, number>)[c.aspect] === 1;
      const isFriction = c.flow === -1 || (ENERGY_ASPECT_FLOW as Record<string, number>)[c.aspect] === -1;
      const dialogue = getHumanDialogue(c.transit, c.aspect, c.natal, isMajor, c.orb);

      return {
        id: c.id,
        transit: c.transit,
        natal: c.natal,
        aspect: c.aspect,
        orb: c.orb,
        isMajor,
        isFlow,
        isFriction,
        strength: c.strength,
        dialogue,
      };
    });
  }, [contacts]);

  // Filtered contacts
  const filteredItems = useMemo(() => {
    return aspectItems.filter(item => {
      // Impact filter
      if (impactFilter === "major" && !item.isMajor) return false;
      if (impactFilter === "minor" && item.isMajor) return false;
      if (impactFilter === "flow" && !item.isFlow) return false;
      if (impactFilter === "friction" && !item.isFriction) return false;

      // Text search
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase();
        const matchesPlanet = item.transit.toLowerCase().includes(query) || item.natal.toLowerCase().includes(query);
        const matchesTitle = item.dialogue.everydayTitle.toLowerCase().includes(query);
        const matchesText = item.dialogue.feelingInBodyAndMind.toLowerCase().includes(query);
        if (!matchesPlanet && !matchesTitle && !matchesText) return false;
      }

      return true;
    });
  }, [aspectItems, impactFilter, searchQuery]);

  const majorCount = useMemo(() => aspectItems.filter(i => i.isMajor).length, [aspectItems]);
  const minorCount = useMemo(() => aspectItems.filter(i => !i.isMajor).length, [aspectItems]);

  return (
    <section
      aria-label="Real-Life Human Aspect Breakdown"
      className="space-y-6 rounded-3xl border border-white/10 bg-[#080B14]/90 p-6 shadow-2xl sm:p-8"
    >
      {/* Section Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-white/10 pb-5">
        <div>
          <div className="flex items-center gap-2">
            <span className="h-2 w-2 rounded-full bg-cyan-400 shadow-[0_0_8px_#22D3EE]" />
            <span className="text-[10px] font-bold uppercase tracking-[0.22em] text-cyan-300">
              Human-to-Human Resonance Guide
            </span>
          </div>
          <h2 className="mt-1 font-serif text-2xl font-bold tracking-tight text-white sm:text-3xl">
            What Today's Aspects Actually Mean in Real Life
          </h2>
          <p className="mt-1 text-xs text-slate-300 max-w-2xl leading-relaxed">
            No dry calculation formulas or confusing astrological jargon. Here is how today's planetary currents actually feel in your body, your work, and your personal relationships.
          </p>
        </div>

        {/* Life-Area Filter Pills */}
        <div className="flex flex-wrap items-center gap-1.5 rounded-xl border border-white/10 bg-white/5 p-1 text-xs">
          {[
            { id: "all", label: "🌟 All Insights", icon: Sparkles },
            { id: "work", label: "💼 Work & Focus", icon: Briefcase },
            { id: "love", label: "❤️ Conversations", icon: Heart },
            { id: "mind", label: "⚡ Inner Feeling", icon: Zap },
          ].map(tab => (
            <button
              key={tab.id}
              type="button"
              onClick={() => setLifeArea(tab.id as any)}
              className={`rounded-lg px-2.5 py-1.5 font-semibold transition-all ${
                lifeArea === tab.id
                  ? "bg-[#D9B66F] text-slate-950 font-bold shadow-sm"
                  : "text-slate-400 hover:text-white"
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Secondary Filter & Search Strip */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        {/* Aspect Weight & Flow Filters */}
        <div className="flex flex-wrap items-center gap-1.5 text-xs">
          {[
            { id: "all", label: `All Aspects (${aspectItems.length})` },
            { id: "major", label: `★ Major Drivers (100% Impact) (${majorCount})` },
            { id: "minor", label: `✧ Minor Vibes (50% Impact) (${minorCount})` },
            { id: "flow", label: "Smooth Flow" },
            { id: "friction", label: "Growth Friction" },
          ].map(btn => (
            <button
              key={btn.id}
              type="button"
              onClick={() => setImpactFilter(btn.id as any)}
              className={`rounded-lg px-2.5 py-1 text-[11px] font-medium transition-all ${
                impactFilter === btn.id
                  ? "border border-cyan-400 bg-cyan-950/60 text-cyan-200"
                  : "border border-white/10 bg-black/30 text-slate-400 hover:text-slate-200"
              }`}
            >
              {btn.label}
            </button>
          ))}
        </div>

        {/* Search Filter */}
        <div className="w-full sm:w-48">
          <input
            type="search"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="Search planets or themes…"
            className="w-full rounded-xl border border-white/10 bg-white/5 px-3 py-1.5 text-xs text-white placeholder-slate-500 focus:border-cyan-400 focus:outline-none"
          />
        </div>
      </div>

      {/* Aspects Cards Grid */}
      {filteredItems.length === 0 ? (
        <div className="rounded-2xl border border-white/10 bg-black/40 p-8 text-center text-sm text-slate-400">
          <Compass className="mx-auto mb-2 h-7 w-7 text-cyan-400/60" />
          <p>No active aspects match your selected filters. Click "All Aspects" to see the full life breakdown.</p>
        </div>
      ) : (
        <div className="grid gap-5 md:grid-cols-2">
          {filteredItems.map(item => {
            const { dialogue } = item;
            const aspectGlyph = ASPECT_GLYPHS[item.aspect] || item.aspect;

            return (
              <article
                key={item.id}
                className={`relative flex flex-col justify-between overflow-hidden rounded-2xl border p-5 transition-all shadow-lg ${
                  item.isMajor
                    ? "border-white/15 bg-[linear-gradient(135deg,#0B1124_0%,#090E1D_100%)] hover:border-amber-400/40"
                    : "border-white/10 bg-[#070A14]/90 hover:border-white/20"
                }`}
              >
                <div>
                  {/* Top Header: Everyday Title + Classification Badge */}
                  <div className="flex items-start justify-between gap-3 border-b border-white/10 pb-3">
                    <div>
                      <span className="text-[10px] font-bold uppercase tracking-wider text-[#D9B66F]">
                        {item.transit} & Natal {item.natal}
                      </span>
                      <h3 className="font-serif text-xl font-bold text-white mt-0.5">
                        {dialogue.everydayTitle}
                      </h3>
                    </div>

                    <div className="flex flex-col items-end gap-1 shrink-0">
                      <span
                        className={`rounded-full px-2 py-0.5 text-[9px] font-bold ${
                          item.isMajor
                            ? "bg-teal-950/80 text-[#2DD4BF] border border-teal-400/40"
                            : "bg-amber-950/80 text-amber-300 border border-amber-400/40"
                        }`}
                      >
                        {item.isMajor ? "★ MAJOR · 100% IMPACT" : "✧ MINOR · 50% IMPACT"}
                      </span>
                      <span className="text-[10px] font-mono text-slate-400">
                        {item.orb.toFixed(2)}° orb
                      </span>
                    </div>
                  </div>

                  {/* Relatable Tagline */}
                  <p className="mt-3 text-xs font-medium text-cyan-200/90 leading-relaxed italic">
                    "{dialogue.tagline}"
                  </p>

                  {/* Dynamic Life Area View */}
                  <div className="mt-4 space-y-3">
                    {(lifeArea === "all" || lifeArea === "mind") && (
                      <div className="rounded-xl border border-white/5 bg-black/40 p-3 text-xs space-y-1">
                        <span className="font-bold text-slate-300 flex items-center gap-1.5 text-[11px]">
                          <Zap size={13} className="text-amber-400" /> What You're Feeling Today
                        </span>
                        <p className="text-slate-300 leading-relaxed text-[12px]">
                          {dialogue.feelingInBodyAndMind}
                        </p>
                      </div>
                    )}

                    {(lifeArea === "all" || lifeArea === "work") && (
                      <div className="rounded-xl border border-teal-500/20 bg-teal-950/20 p-3 text-xs space-y-1">
                        <span className="font-bold text-teal-300 flex items-center gap-1.5 text-[11px]">
                          <Briefcase size={13} /> Work, Focus & Projects
                        </span>
                        <p className="text-slate-300 leading-relaxed text-[12px]">
                          {dialogue.workAndMoney}
                        </p>
                      </div>
                    )}

                    {(lifeArea === "all" || lifeArea === "love") && (
                      <div className="rounded-xl border border-rose-500/20 bg-rose-950/20 p-3 text-xs space-y-1">
                        <span className="font-bold text-rose-300 flex items-center gap-1.5 text-[11px]">
                          <Heart size={13} /> Conversations & Relationships
                        </span>
                        <p className="text-slate-300 leading-relaxed text-[12px]">
                          {dialogue.relationshipsAndPeople}
                        </p>
                      </div>
                    )}

                    {/* Green Advice vs Red Trap */}
                    <div className="grid gap-2 sm:grid-cols-2 pt-1 text-xs">
                      <div className="rounded-xl border border-emerald-500/20 bg-emerald-950/20 p-2.5">
                        <span className="font-bold text-emerald-300 flex items-center gap-1 text-[11px]">
                          <CheckCircle2 size={12} /> Best Move
                        </span>
                        <p className="mt-1 text-slate-300 text-[11px] leading-relaxed">
                          {dialogue.bestMoveToday}
                        </p>
                      </div>

                      <div className="rounded-xl border border-rose-500/20 bg-rose-950/20 p-2.5">
                        <span className="font-bold text-rose-300 flex items-center gap-1 text-[11px]">
                          <AlertCircle size={12} /> Trap to Avoid
                        </span>
                        <p className="mt-1 text-slate-300 text-[11px] leading-relaxed">
                          {dialogue.trapToAvoid}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Bottom Footer Action */}
                <div className="mt-4 pt-3 border-t border-white/5 flex items-center justify-between text-xs">
                  <span className="text-[10px] font-mono text-slate-500">
                    {item.isMajor ? "100% gravitational weight" : "50% subtle background nuance"}
                  </span>

                  {onAskQuestion && (
                    <button
                      type="button"
                      onClick={() =>
                        onAskQuestion(
                          `In everyday human terms: how does transit ${item.transit} ${item.aspect} my natal ${item.natal} affect my life today, and how do I navigate it?`
                        )
                      }
                      className="inline-flex items-center gap-1 text-[11px] font-semibold text-cyan-300 hover:text-cyan-200 transition"
                    >
                      <MessageSquare size={13} />
                      <span>Ask Master Interpreter →</span>
                    </button>
                  )}
                </div>
              </article>
            );
          })}
        </div>
      )}

      {/* Explanatory Guidance Strip */}
      <div className="rounded-2xl border border-white/5 bg-black/40 p-4 text-xs text-slate-400 space-y-1">
        <strong className="text-slate-300">How to use this breakdown:</strong>
        <p className="leading-relaxed">
          Focus on your <strong className="text-teal-300">Major Aspects</strong> (100% impact) for the big decisions, conversations, and career commitments of your day. Treat <strong className="text-amber-300">Minor Aspects</strong> (50% impact) as underlying background vibes or small adjustments.
        </p>
      </div>
    </section>
  );
}
