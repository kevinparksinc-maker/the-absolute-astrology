// Plain-English, high-depth interpretations for planetary transit contacts
// Translates raw astronomical geometry into actionable daily life guidance.

export interface AspectInterpretation {
  summary: string;
  feeling: string;
  bestFor: string;
  caution: string;
}

const PLANET_KEYWORDS: Record<string, { theme: string; manifestation: string }> = {
  Sun: { theme: "Core identity, vitality, confidence, purpose", manifestation: "Your central will and life force" },
  Moon: { theme: "Emotions, intuition, home, bodily rhythm", manifestation: "Your emotional climate and immediate reactions" },
  Mercury: { theme: "Communication, contracts, thinking, mental focus", manifestation: "Your voice, decisions, and processing speed" },
  Venus: { theme: "Relationships, finances, harmony, aesthetic values", manifestation: "Love, negotiations, and social rapport" },
  Mars: { theme: "Action, drive, initiative, boundaries, ambition", manifestation: "Your courage, momentum, and physical stamina" },
  Jupiter: { theme: "Expansion, optimism, luck, wisdom, opportunities", manifestation: "Growth, perspective, and doors opening" },
  Saturn: { theme: "Discipline, structure, responsibility, reality checks", manifestation: "Grounding, commitments, and necessary boundaries" },
  Uranus: { theme: "Breakthroughs, innovation, sudden shifts, freedom", manifestation: "Unexpected insights and desire for authenticity" },
  Neptune: { theme: "Imagination, spiritual connection, dreams, subtle flow", manifestation: "Intuition, empathy, and creative inspiration" },
  Pluto: { theme: "Transformation, empowerment, truth, psychological rebirth", manifestation: "Deep motivation and releasing outworn habits" },
  "North Node": { theme: "Future direction, growth edge, karmic evolution", manifestation: "Stepping toward your next chapter" },
  "South Node": { theme: "Past familiarity, natural gifts, release", manifestation: "Old patterns to integrate with wisdom" },
  Ascendant: { theme: "Personal presence, outlook, first impressions", manifestation: "How you meet the world and navigate your day" },
};

export function getPlainEnglishInterpretation(
  transitPlanet: string,
  aspect: string,
  natalPlanet: string,
  isMajor: boolean
): AspectInterpretation {
  const tInfo = PLANET_KEYWORDS[transitPlanet] || { theme: transitPlanet, manifestation: "Cosmic influence" };
  const nInfo = PLANET_KEYWORDS[natalPlanet] || { theme: natalPlanet, manifestation: "Personal capacity" };

  const isHarmonious = ["conjunction", "trine", "sextile", "semisextile"].includes(aspect);
  const isFriction = ["square", "opposition", "semisquare", "quincunx"].includes(aspect);

  const aspectWeightNote = isMajor
    ? "This is a major celestial contact exerting full foundational momentum in your day."
    : "This is a subtle minor aspect (50% impact) working as an underlying secondary current.";

  if (isHarmonious) {
    return {
      summary: `Supportive alignment between transit ${transitPlanet} and your natal ${natalPlanet}. ${aspectWeightNote}`,
      feeling: `You feel a natural sense of synchronization between ${tInfo.manifestation.toLowerCase()} and your ${nInfo.manifestation.toLowerCase()}. Things tend to click without forced effort.`,
      bestFor: `Making progress on ${tInfo.theme.toLowerCase()}, having constructive discussions, initiating projects, and collaborating smoothly.`,
      caution: `Avoid complacency—because energy flows smoothly, take deliberate action to maximize this golden window.`,
    };
  }

  if (isFriction) {
    return {
      summary: `Dynamic tension between transit ${transitPlanet} and your natal ${natalPlanet}. ${aspectWeightNote}`,
      feeling: `You may notice friction between ${tInfo.manifestation.toLowerCase()} and your ${nInfo.manifestation.toLowerCase()}. Minor delays, impatience, or competing priorities can spark irritability if rushed.`,
      bestFor: `Tackling tough problems that require grit, breaking through stagnation, setting firm personal boundaries, and honest self-reflection.`,
      caution: `Avoid knee-jerk arguments, impulsive financial commitments, or forcing decisions when emotions feel elevated. Pause before responding.`,
    };
  }

  return {
    summary: `Active energetic contact between transit ${transitPlanet} and your natal ${natalPlanet}. ${aspectWeightNote}`,
    feeling: `A transitional blend of ${tInfo.manifestation.toLowerCase()} meeting your ${nInfo.manifestation.toLowerCase()}.`,
    bestFor: `Observing patterns, making minor adjustments, and staying adaptable.`,
    caution: `Don't rush commitments until the planetary momentum settles into clear focus.`,
  };
}

export function getAtmosphereDescription(flowPct: number, moonSign?: string): { title: string; subtitle: string; tone: "flow" | "dynamic" | "friction" } {
  if (flowPct >= 65) {
    return {
      title: "Harmonious Sky Weather (Open Flow)",
      subtitle: moonSign
        ? `The cosmic atmosphere is supportive and receptive with Moon moving through ${moonSign}. Ambient conditions favor constructive engagement.`
        : "The cosmic atmosphere is supportive and receptive. Ambient conditions favor constructive engagement and smooth interactions.",
      tone: "flow",
    };
  }
  if (flowPct <= 38) {
    return {
      title: "Intense Sky Weather (High Friction)",
      subtitle: moonSign
        ? `The environmental sky carries noticeable pressure and catalytic tension with Moon in ${moonSign}. Collective currents are reactive.`
        : "The environmental sky carries noticeable pressure and catalytic tension. Collective currents are reactive; practice grounded patience.",
      tone: "friction",
    };
  }
  return {
    title: "Balanced Sky Weather (Dynamic Movement)",
    subtitle: moonSign
      ? `The sky presents a balanced mix of flow and growth challenges with Moon in ${moonSign}. Momentum responds directly to deliberate focus.`
      : "The sky presents a balanced mix of flow and growth challenges. Momentum responds directly to deliberate focus and steady pacing.",
    tone: "dynamic",
  };
}
