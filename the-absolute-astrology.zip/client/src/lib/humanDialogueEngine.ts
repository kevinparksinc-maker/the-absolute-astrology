// Human-to-Human Resonance Dialogue Engine
// Translates raw planetary aspects into warm, conversational, everyday life translations.
// Zero math dumps — only empathetic, relatable human guidance.

export interface HumanAspectDialogue {
  everydayTitle: string;
  tagline: string;
  feelingInBodyAndMind: string;
  workAndMoney: string;
  relationshipsAndPeople: string;
  bestMoveToday: string;
  trapToAvoid: string;
  isMajor: boolean;
  impactExplanation: string;
}

interface PlanetPairProfile {
  titleHarmonious: string;
  titleFriction: string;
  titleNeutral: string;
  taglineHarmonious: string;
  taglineFriction: string;
  taglineNeutral: string;
  feelingHarmonious: string;
  feelingFriction: string;
  feelingNeutral: string;
  workHarmonious: string;
  workFriction: string;
  workNeutral: string;
  loveHarmonious: string;
  loveFriction: string;
  loveNeutral: string;
  bestMoveHarmonious: string;
  bestMoveFriction: string;
  bestMoveNeutral: string;
  trapHarmonious: string;
  trapFriction: string;
  trapNeutral: string;
}

const SPECIFIC_PAIR_PROFILES: Record<string, PlanetPairProfile> = {
  "Sun-Moon": {
    titleHarmonious: "Inner Harmony & Clarity",
    titleFriction: "Head vs. Heart Tug-of-War",
    titleNeutral: "Self-Awareness Shift",
    taglineHarmonious: "What you want logically and what you need emotionally are in complete agreement.",
    taglineFriction: "Your conscious goals are clashing with your emotional comfort zone.",
    taglineNeutral: "A quiet moment of reflection between who you are and where you are going.",
    feelingHarmonious: "You feel centered and steady in your skin. Your gut instincts and rational brain are speaking the exact same language today.",
    feelingFriction: "You might feel split in two directions: one part of you wants to push forward and get things done, while another part just wants to retreat or feels drained.",
    feelingNeutral: "A subtle background rhythm where emotional needs come up for a quick check-in.",
    workHarmonious: "Great day for presentations, pitching yourself, and making decisions that feel authentic to who you are.",
    workFriction: "Don't force a high-stakes decision if your gut is hesitating. Give yourself overnight to sleep on big choices.",
    workNeutral: "Steady routine work. Realign your to-do list with what actually matters to you.",
    loveHarmonious: "Conversations with partners and family feel smooth and validating. Easy to connect without defensiveness.",
    loveFriction: "You might take comments more personally than intended. Step back before reacting to emotional triggers.",
    loveNeutral: "Gentle listening. Ask people how they are doing and share how you genuinely feel.",
    bestMoveHarmonious: "Take decisive action on a personal project you've been putting off.",
    bestMoveFriction: "Acknowledge what you're actually feeling instead of trying to bulldoze through it.",
    bestMoveNeutral: "Check in with yourself before saying yes to outside demands.",
    trapHarmonious: "Assuming everyone else is on your exact wavelength—keep communication clear.",
    trapFriction: "Making permanent life decisions based on a temporary emotional storm.",
    trapNeutral: "Ignoring subtle bodily tiredness.",
  },
  "Sun-Mars": {
    titleHarmonious: "Confident Momentum",
    titleFriction: "The Friction Spark (Short Fuse)",
    titleNeutral: "Energy Adjustment",
    taglineHarmonious: "High stamina, courage, and the ability to get things done quickly.",
    taglineFriction: "Urges to rush, push back against authority, or force things to happen now.",
    taglineNeutral: "Your physical drive is recalibrating.",
    feelingHarmonious: "You have natural vitality and self-assurance. You don't feel like waiting around—you want to tackle challenges head-on.",
    feelingFriction: "Impatience is running high. You might feel irritable if someone cuts you off, moves slowly, or questions your direction.",
    feelingNeutral: "A steady pulse of energy that needs a constructive outlet.",
    workHarmonious: "Crush your hardest tasks first. Excellent for negotiations where you need to stand your ground with confidence.",
    workFriction: "Channel the fire into solo hard work. Do NOT send impulsive emails or pick fights with bosses/clients.",
    workNeutral: "Break large goals into quick 30-minute sprint blocks.",
    loveHarmonious: "Playful, passionate, and direct. Great for fun outings or honest, open conversations.",
    loveFriction: "Watch your tone. What feels like 'just being direct' to you might come across as aggressive or defensive to others.",
    loveNeutral: "Be honest about what you need without escalating small annoyances.",
    bestMoveHarmonious: "Put physical effort into a demanding task or workout.",
    bestMoveFriction: "Take 10 deep breaths and go for a brisk walk before addressing a conflict.",
    bestMoveNeutral: "Focus your energy on one specific target at a time.",
    trapHarmonious: "Overcommitting your physical stamina.",
    trapFriction: "Burning bridges over trivial ego disagreements.",
    trapNeutral: "Restless fidgeting without completing tasks.",
  },
  "Sun-Jupiter": {
    titleHarmonious: "The Golden Opportunity",
    titleFriction: "Overpromising & Big Eyes",
    titleNeutral: "Expanding Horizon",
    taglineHarmonious: "Optimism is justified, luck is on your side, and people want to say yes to you.",
    taglineFriction: "Temptation to bite off way more than you can chew or spend money prematurely.",
    taglineNeutral: "A gentle nudge to think bigger and cultivate gratitude.",
    feelingHarmonious: "Generous, upbeat, and mentally spacious. Problems that felt heavy yesterday seem completely manageable today.",
    feelingFriction: "You feel ambitious, but you might underestimate how much time, money, or effort something actually requires.",
    feelingNeutral: "A healthy curiosity about the future and learning new perspectives.",
    workHarmonious: "Pitch the big idea, ask for the meeting, or apply for the position. Luck favors bold preparation today.",
    workFriction: "Double-check the fine print and budget. Dream big, but verify the practical execution timeline.",
    workNeutral: "Research long-term training, travel, or strategic partnerships.",
    loveHarmonious: "Warm, forgiving, and uplifting. Great time to celebrate with friends or plan a memorable trip.",
    loveFriction: "Be careful not to make grand promises you can't realistically keep next week.",
    loveNeutral: "Share inspiring stories or express heartfelt appreciation.",
    bestMoveHarmonious: "Say yes to invitations and initiate conversations with mentors.",
    bestMoveFriction: "Scale back expectations by 20% to keep things realistic and sustainable.",
    bestMoveNeutral: "Read something that stretches your mind.",
    trapHarmonious: "Being so confident that you skip the essential preparatory details.",
    trapFriction: "Impulsive overspending on luxury or speculative bets.",
    trapNeutral: "Daydreaming without writing down actionable next steps.",
  },
  "Sun-Saturn": {
    titleHarmonious: "Rock-Solid Grounding",
    titleFriction: "The Reality Check (Weight on Shoulders)",
    titleNeutral: "Structural Checkup",
    taglineHarmonious: "Patient discipline pays off; you earn respect through steady consistency.",
    taglineFriction: "Self-doubt, feeling unappreciated, or running into strict limits and delays.",
    taglineNeutral: "A sober look at your responsibilities and daily routines.",
    feelingHarmonious: "Calm, mature, and focused. You don't need instant gratification; you take quiet pride in doing things the right way.",
    feelingFriction: "You might feel like you're carrying the weight of the world alone. Imposter syndrome or feeling critical of yourself can creep in.",
    feelingNeutral: "Practical and no-nonsense. You just want things organized and reliable.",
    workHarmonious: "Finish long-term projects, organize finances, set boundaries, and earn the trust of senior stakeholders.",
    workFriction: "Don't take setbacks personally. Delays right now are quality control, not permanent failure. Focus on one small duty at a time.",
    workNeutral: "Review contracts, clear out paper trails, and tidy your workspace.",
    loveHarmonious: "Loyal, dependable companionship. Actions speak louder than sugary words today.",
    loveFriction: "You might feel emotionally guarded or distant. Let people know you're just preoccupied, not upset with them.",
    loveNeutral: "Keep your word on small commitments.",
    bestMoveHarmonious: "Build something durable: an organized budget, a workout schedule, or a solid plan.",
    bestMoveFriction: "Silence your inner critic. Treat yourself with the same compassion you'd give a hard-working friend.",
    bestMoveNeutral: "Prioritize your top 3 responsibilities and let the rest wait.",
    trapHarmonious: "Being too rigid or all work and no play.",
    trapFriction: "Giving up right before the finish line because progress feels slow.",
    trapNeutral: "Pessimism masked as realism.",
  },
  "Moon-Mercury": {
    titleHarmonious: "Heart-to-Heart Flow",
    titleFriction: "Overthinking Emotional Needs",
    titleNeutral: "Expressive Curiosity",
    taglineHarmonious: "You can express exactly how you feel with tact, empathy, and clear logic.",
    taglineFriction: "Your mind is spinning with worried 'what-ifs' or dissecting emotional comments.",
    taglineNeutral: "Reflective journaling or talking through a problem with a trusted friend.",
    feelingHarmonious: "Mentally agile and emotionally perceptive. You intuitively pick up on what other people are really saying between the lines.",
    feelingFriction: "Mental restlessness. You might try to intellectualize or rationalize feelings that simply need to be acknowledged.",
    feelingNeutral: "Curious and observant about your own thought patterns.",
    workHarmonious: "Drafting sensitive emails, customer communications, writing, teaching, and mediating disputes.",
    workFriction: "Step away from screens if you feel information overload. Don't reply to tense messages in a rush.",
    workNeutral: "Make lists, clean out your inbox, and organize your thoughts on paper.",
    loveHarmonious: "A beautiful time for intimate talks. Vulnerability is met with understanding.",
    loveFriction: "Avoid debating someone's feelings with technical logic. Validate first, problem-solve second.",
    loveNeutral: "Ask questions and genuinely listen to the answers.",
    bestMoveHarmonious: "Have the conversation you've been delaying—words flow smoothly today.",
    bestMoveFriction: "Write your unfiltered thoughts in a private journal to get them out of your head.",
    bestMoveNeutral: "Call a supportive friend for a casual check-in.",
    trapHarmonious: "Talking so much you forget to pause and listen.",
    trapFriction: "Reading between the lines of texts that have no hidden meaning.",
    trapNeutral: "Getting distracted by trivia.",
  },
  "Moon-Mars": {
    titleHarmonious: "Passionate Gut Drive",
    titleFriction: "Emotional Pressure Cooker",
    titleNeutral: "Instinctive Alertness",
    taglineHarmonious: "High emotional courage and the instinctive drive to protect and initiate.",
    taglineFriction: "Quick temper, defensiveness, or mood swings triggered by small frustrations.",
    taglineNeutral: "Quick reflexes and heightened responsiveness to your environment.",
    feelingHarmonious: "Dynamic and spirited. You have the guts to stand up for yourself and your loved ones without hesitating.",
    feelingFriction: "You might feel thin-skinned. Someone's tone or a minor delay can trigger an intense rush of irritation.",
    feelingNeutral: "Alert and ready to jump into action if required.",
    workHarmonious: "Tackle physical tasks, fight for a project you believe in, or work through a physically demanding day.",
    workFriction: "Walk away from heated office arguments. Give yourself 20 minutes before reacting to frustrating news.",
    workNeutral: "Direct energy into high-speed execution.",
    loveHarmonious: "Passionate, romantic, and deeply loyal. Fun, high-energy dates are favored.",
    loveFriction: "Watch out for domestic bickering over petty chores. Express your frustration constructively without attacking.",
    loveNeutral: "Do something active together, like cooking or walking.",
    bestMoveHarmonious: "Use this burst of emotional energy to fix something broken in your life.",
    bestMoveFriction: "Do strenuous physical exercise to burn off excess adrenaline.",
    bestMoveNeutral: "Stay mindful of your physical pace.",
    trapHarmonious: "Moving so fast you bump into things or drop objects.",
    trapFriction: "Saying something hurtful that you can't take back once the mood passes.",
    trapNeutral: "Restless sleep.",
  },
  "Venus-Mars": {
    titleHarmonious: "Magnetic Social Chemistry",
    titleFriction: "Desire vs. Compromise Friction",
    titleNeutral: "Creative Spark",
    taglineHarmonious: "Charm meets confidence. Romantic sparks fly and social interactions feel electric.",
    taglineFriction: "Sparks fly in both ways: passionate attraction or stubborn clashes over desires.",
    taglineNeutral: "A blend of aesthetic appreciation and creative drive.",
    feelingHarmonious: "Playful, attractive, and socially energized. You naturally draw people in without even trying.",
    feelingFriction: "Tension between wanting your own way and keeping the peace with a partner or colleague.",
    feelingNeutral: "An urge to make things look beautiful or redecorate.",
    workHarmonious: "Ideal for creative design, sales pitches, collaboration, and networking events.",
    workFriction: "Compromise is required. Don't let pride prevent a mutually beneficial agreement.",
    workNeutral: "Focus on aesthetics, branding, or creative crafts.",
    loveHarmonious: "One of the best planetary connections for romance, intimacy, and memorable dates.",
    loveFriction: "Clear the air honestly if resentment is brewing, but avoid passive-aggressive ultimatums.",
    loveNeutral: "Express attraction or gratitude openly.",
    bestMoveHarmonious: "Plan a romantic evening or put your best foot forward at a social event.",
    bestMoveFriction: "Find the middle ground where both people feel valued and respected.",
    bestMoveNeutral: "Invest in something that brings genuine joy and beauty to your space.",
    trapHarmonious: "Spending money impulsively on things you won't care about next week.",
    trapFriction: "Confusing dramatic conflict with real intimacy.",
    trapNeutral: "Procrastinating on hard chores for social fun.",
  },
  "Mercury-Uranus": {
    titleHarmonious: "The Eureka Flash",
    titleFriction: "Mental Scatter & Curveballs",
    titleNeutral: "Unconventional Idea",
    taglineHarmonious: "Instant flashes of genius, breakthroughs on old problems, and original thinking.",
    taglineFriction: "Scattered attention, unexpected tech hiccups, or blurted out statements.",
    taglineNeutral: "An urge to break routine and try an unconventional method.",
    feelingHarmonious: "Your mind feels like lightning. Solutions to problems you've struggled with for weeks suddenly appear out of thin air.",
    feelingFriction: "Mentally over-stimulated. Too many tabs open in your brain; hard to sit still and focus on mundane tasks.",
    feelingNeutral: "Curious, open to weird facts, and thinking outside the standard box.",
    workHarmonious: "Brainstorming, coding, innovation, tech troubleshooting, and adopting modern tools.",
    workFriction: "Back up your data, read emails twice before hitting send, and expect minor scheduling audibles.",
    workNeutral: "Experiment with an automated shortcut or new workflow.",
    loveHarmonious: "Fascinating conversations, laughing over unexpected humor, and meeting unique minds.",
    loveFriction: "Try not to be argumentative just for the sake of being contrarian.",
    loveNeutral: "Give each other plenty of intellectual freedom and breathing room.",
    bestMoveHarmonious: "Write down your wild ideas immediately before you forget them.",
    bestMoveFriction: "Unplug from social media and step into nature to ground your nervous system.",
    bestMoveNeutral: "Try a different route to work or change your routine.",
    trapHarmonious: "Talking faster than people can absorb your ideas.",
    trapFriction: "Ghosting plans or abruptly changing your mind without notifying others.",
    trapNeutral: "Information rabbit holes that steal your afternoon.",
  },
  "Mars-Saturn": {
    titleHarmonious: "Iron Discipline & Endurance",
    titleFriction: "The Foot-on-the-Brake Gridlock",
    titleNeutral: "Patience Trial",
    taglineHarmonious: "Strategic pacing, unstoppable stamina, and mastering difficult challenges.",
    taglineFriction: "Pushing hard against a closed door; delays and bureaucracy testing your temper.",
    taglineNeutral: "Measuring your strength against a solid constraint.",
    feelingHarmonious: "Grounded and stoic. You are willing to put in the hard hours because you know the foundation will last.",
    feelingFriction: "Frustration. You feel ready to sprint, but circumstances or red tape force you into a slow crawl.",
    feelingNeutral: "Carefully rationing your energy for the long haul.",
    workHarmonious: "Tackling exhausting manual or technical projects that require zero mistakes.",
    workFriction: "Do not force a breakthrough by raw aggression. Slow down, respect protocol, and play the long game.",
    workNeutral: "Set realistic milestones rather than sprinting to exhaustion.",
    loveHarmonious: "Reliable support during tough times. Proving loyalty through steady presence.",
    loveFriction: "Avoid cold-shoulder standoffs. If you are angry, express it with cool maturity, not stony silence.",
    loveNeutral: "Honoring shared duties and promises.",
    bestMoveHarmonious: "Work steadily on your most difficult responsibility.",
    bestMoveFriction: "Accept that timing isn't right for instant results; sharpen your tools while waiting.",
    bestMoveNeutral: "Pace your physical exertion.",
    trapHarmonious: "Being unforgiving of others who have less stamina than you.",
    trapFriction: "Banging your head against a brick wall until you injure your morale.",
    trapNeutral: "Resentment toward necessary rules.",
  },
};

export function getHumanDialogue(
  transitPlanet: string,
  aspect: string,
  natalPlanet: string,
  isMajor: boolean,
  orb: number
): HumanAspectDialogue {
  const isHarmonious = ["conjunction", "trine", "sextile", "semisextile"].includes(aspect);
  const isFriction = ["square", "opposition", "semisquare", "quincunx"].includes(aspect);
  const modeKey = isHarmonious ? "Harmonious" : isFriction ? "Friction" : "Neutral";

  // Check direct or reverse pair
  const directKey = `${transitPlanet}-${natalPlanet}`;
  const reverseKey = `${natalPlanet}-${transitPlanet}`;
  const specific = SPECIFIC_PAIR_PROFILES[directKey] || SPECIFIC_PAIR_PROFILES[reverseKey];

  const aspectImpactNote = isMajor
    ? "★ Major Aspect (100% Impact) — This is a primary gravitational force shaping the dominant theme of your day."
    : "✧ Minor Aspect (50% Impact) — This is an underlying subtle current that operates as background nuance.";

  if (specific) {
    return {
      everydayTitle: specific[`title${modeKey}` as keyof PlanetPairProfile],
      tagline: specific[`tagline${modeKey}` as keyof PlanetPairProfile],
      feelingInBodyAndMind: specific[`feeling${modeKey}` as keyof PlanetPairProfile],
      workAndMoney: specific[`work${modeKey}` as keyof PlanetPairProfile],
      relationshipsAndPeople: specific[`love${modeKey}` as keyof PlanetPairProfile],
      bestMoveToday: specific[`bestMove${modeKey}` as keyof PlanetPairProfile],
      trapToAvoid: specific[`trap${modeKey}` as keyof PlanetPairProfile],
      isMajor,
      impactExplanation: aspectImpactNote,
    };
  }

  // Generative fallback with high human resonance
  const actionTone = isHarmonious
    ? "flow smoothly together"
    : isFriction
    ? "create dynamic growth friction"
    : "blend in a transitional way";

  return {
    everydayTitle: isHarmonious
      ? `${transitPlanet} Synchronized with ${natalPlanet}`
      : isFriction
      ? `${transitPlanet} Challenging ${natalPlanet}`
      : `${transitPlanet} Connecting with ${natalPlanet}`,
    tagline: `How transit ${transitPlanet} and your natal ${natalPlanet} ${actionTone} in your life today.`,
    feelingInBodyAndMind: isHarmonious
      ? `You experience a feeling of natural flow between your ${transitPlanet.toLowerCase()} energy and your personal ${natalPlanet.toLowerCase()} qualities. Things feel intuitive and unforced.`
      : isFriction
      ? `You might feel internal friction between the outside demands of ${transitPlanet.toLowerCase()} and your inner ${natalPlanet.toLowerCase()} needs. A prompt to slow down and stay grounded.`
      : `An adaptable, shifting awareness between outside influences and your personal traits.`,
    workAndMoney: isHarmonious
      ? `Favorable for advancing projects related to ${transitPlanet.toLowerCase()} themes. Collaborate, propose ideas, and move forward with steady confidence.`
      : isFriction
      ? `Avoid rushed financial or career commitments today. Check the fine print and pause before agreeing under pressure.`
      : `Handle routine tasks with mindful attention to detail.`,
    relationshipsAndPeople: isHarmonious
      ? `Conversations feel supportive. People are more receptive to your ideas and intentions.`
      : isFriction
      ? `Give others extra breathing room. Misunderstandings are easily defused with calm listening rather than immediate debate.`
      : `Stay curious and open to differing viewpoints.`,
    bestMoveToday: isHarmonious
      ? `Take active advantage of this supportive planetary window.`
      : isFriction
      ? `Take deep breaths and channel tension into productive solo effort.`
      : `Observe patterns without forcing outcomes.`,
    trapToAvoid: isHarmonious
      ? `Letting a good opportunity pass by due to complacency.`
      : isFriction
      ? `Overreacting to temporary outside friction or impatience.`
      : `Scattering your focus over minor distractions.`,
    isMajor,
    impactExplanation: aspectImpactNote,
  };
}
